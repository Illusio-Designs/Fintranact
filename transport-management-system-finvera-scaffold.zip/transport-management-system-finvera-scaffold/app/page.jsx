import Image from 'next/image';
import AgencyClient from './AgencyClient';

const HERO_TITLE = [
  ['Numbers', false],
  ['that', false],
  ['build', false],
  ['trust.', true],
];

const SERVICES = [
  {
    n: '01',
    title: 'Brand & identity',
    desc: 'Wordmarks, design systems, and visual languages that let finance feel human, modern, and unmistakable.',
    tags: ['Logo', 'Identity', 'Guidelines', 'Type'],
  },
  {
    n: '02',
    title: 'Accounting websites',
    desc: 'Lead-magnet sites and dashboards engineered for clarity, conversion, and the rigor your audit committee expects.',
    tags: ['Next.js', 'CMS', 'SEO', 'Analytics'],
  },
  {
    n: '03',
    title: 'Finance product UX',
    desc: 'From invoicing to AR/AP automation — interfaces that turn complex ledgers into one-glance decisions.',
    tags: ['Research', 'Flows', 'Prototyping', 'Design Ops'],
  },
  {
    n: '04',
    title: 'Growth & content',
    desc: 'Lifecycle email, performance creative, and editorial that compounds organic pipeline month over month.',
    tags: ['SEO', 'Lifecycle', 'Performance', 'Editorial'],
  },
];

const WORK = [
  {
    media: 'fv-work__media',
    shape: 'F',
    label: ['CASE STUDY · 2025', 'FINTECH'],
    title: 'Ledger that <em>thinks</em> ahead.',
    desc: 'Reimagined a B2B accounting suite into a unified close — 38% faster month-end, 4× faster onboarding, and a brand that finally felt like the product.',
    tags: ['Strategy', 'Identity', 'Product UX', 'Web'],
  },
  {
    media: 'fv-work__media fv-work__media--alt',
    shape: '$',
    label: ['CASE STUDY · 2024', 'PAYMENTS'],
    title: 'Compliance, but <em>quietly</em>.',
    desc: 'Took a payments compliance platform from spreadsheet-feel to category-defining. Doubled qualified demos in the first quarter post-launch.',
    tags: ['Brand', 'Site', 'Motion', 'SEO'],
  },
  {
    media: 'fv-work__media fv-work__media--soft',
    shape: '%',
    label: ['CASE STUDY · 2024', 'WEALTH'],
    title: 'Wealth made <em>readable</em>.',
    desc: 'A retail wealth advisor needed to explain complex portfolios without the suit. We delivered an editorial system clients actually share.',
    tags: ['Editorial', 'Identity', 'Web', 'Illustration'],
  },
];

const STEPS = [
  { title: 'Discover', body: 'Workshops, audits, and interviews to map the real problem behind the brief.' },
  { title: 'Define', body: 'Narrative, audience, and a sharp one-page strategy everyone can rally behind.' },
  { title: 'Design', body: 'Brand, product, and web crafted in parallel — never in silos.' },
  { title: 'Deliver', body: 'Ship, measure, and iterate. We stay in the trenches after launch.' },
];

const LOGOS = [
  'Northbridge Capital', 'Vance & Co.', 'Atlas Ledger', 'Westmark Audit',
  'Helios Pay', 'Quanta Wealth', 'Beacon CFO', 'Foundry Tax', 'Ridgepoint',
];

export default function AgencyPage() {
  return (
    <main id="top">
      <Loader />
      <AgencyClient />

      {/* HERO */}
      <section className="fv-hero">
        <div className="fv-container">
          <span className="fv-hero__eyebrow">Independent agency · Est. 2019</span>

          <h1 className="fv-hero__title">
            {HERO_TITLE.map(([word, accent], i) => (
              <span key={i} className={`fv-word ${accent ? 'fv-word--accent' : ''}`}>
                <span style={{ animationDelay: `${0.7 + i * 0.12}s` }}>{word}</span>
              </span>
            ))}
          </h1>

          <div className="fv-hero__row">
            <p className="fv-hero__lead">
              Finvera is a creative studio for finance and accounting brands.
              We turn ledgers, audits, and policies into experiences clients
              actually trust — and act on.
            </p>
            <div className="fv-hero__actions">
              <a className="fv-btn" href="#contact" data-magnet>
                Start a project <span className="fv-btn__arrow">→</span>
              </a>
              <a className="fv-btn fv-btn--ghost" href="#work" data-magnet>
                See our work
              </a>
            </div>
          </div>

          <div className="fv-scroll-hint">scroll to explore</div>
        </div>

        <Image
          src="/finvera-mark.png"
          alt=""
          aria-hidden="true"
          width={480}
          height={480}
          priority
          className="fv-hero__bolt"
        />
      </section>

      {/* MARQUEE */}
      <Marquee />

      {/* SERVICES */}
      <section id="services" className="fv-section">
        <div className="fv-container">
          <header className="fv-section__head fv-reveal">
            <div>
              <span className="fv-tag">What we do</span>
              <h2 className="fv-section__title">
                Strategy, design, and engineering<br />
                for <em>finance brands</em>.
              </h2>
            </div>
            <p className="fv-section__lead">
              We work as one embedded team across brand, product, and web —
              so your story, interface, and numbers finally agree.
            </p>
          </header>

          <div className="fv-services fv-reveal-stagger">
            {SERVICES.map((s) => (
              <article key={s.n} className="fv-service">
                <span className="fv-service__num">— {s.n}</span>
                <h3 className="fv-service__title">{s.title}</h3>
                <p className="fv-service__desc">{s.desc}</p>
                <ul className="fv-service__list">
                  {s.tags.map((t) => <li key={t}>{t}</li>)}
                </ul>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* STATS */}
      <section className="fv-section" style={{ paddingTop: 0 }}>
        <div className="fv-container fv-reveal">
          <div className="fv-stats">
            <div className="fv-stats__grid">
              <div>
                <div className="fv-stat__num">
                  <span data-count="120" data-suffix="+">0</span>
                </div>
                <div className="fv-stat__label">Brands shaped</div>
              </div>
              <div>
                <div className="fv-stat__num">
                  <em><span data-count="38" data-suffix="%">0</span></em>
                </div>
                <div className="fv-stat__label">Avg. lift in conversions</div>
              </div>
              <div>
                <div className="fv-stat__num">
                  <span data-count="14">0</span>
                </div>
                <div className="fv-stat__label">Industry awards</div>
              </div>
              <div>
                <div className="fv-stat__num">
                  <em><span data-count="6">0</span></em>
                </div>
                <div className="fv-stat__label">Years in finance</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* WORK */}
      <section id="work" className="fv-section" style={{ paddingTop: 0 }}>
        <div className="fv-container">
          <header className="fv-section__head fv-reveal">
            <div>
              <span className="fv-tag">Selected work</span>
              <h2 className="fv-section__title">
                Receipts, not <em>slogans</em>.
              </h2>
            </div>
            <p className="fv-section__lead">
              A snapshot of recent engagements across fintech, payments, and
              wealth — measured in pipeline, not just pixels.
            </p>
          </header>

          <div className="fv-work fv-reveal-stagger">
            {WORK.map((w, i) => (
              <article key={i} className="fv-work__card">
                <div className={w.media}>
                  <span className="fv-work__shape">{w.shape}</span>
                  <Image
                    src="/finvera-mark.png"
                    alt=""
                    aria-hidden="true"
                    width={400}
                    height={400}
                    className="fv-work__bolt"
                  />
                </div>
                <div>
                  <div className="fv-work__meta">
                    {w.label.map((l) => <span key={l}>{l}</span>)}
                  </div>
                  <h3
                    className="fv-work__title"
                    dangerouslySetInnerHTML={{ __html: w.title }}
                  />
                  <p className="fv-work__desc">{w.desc}</p>
                  <ul className="fv-work__tags">
                    {w.tags.map((t) => <li key={t}>{t}</li>)}
                  </ul>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* PROCESS */}
      <section id="process" className="fv-section" style={{ paddingTop: 0 }}>
        <div className="fv-container">
          <header className="fv-section__head fv-reveal">
            <div>
              <span className="fv-tag">Process</span>
              <h2 className="fv-section__title">
                Calm, <em>focused</em>, in&nbsp;public.
              </h2>
            </div>
            <p className="fv-section__lead">
              No black boxes. You see the strategy, the work, and the numbers
              every step of the way — in one shared workspace.
            </p>
          </header>

          <div className="fv-process fv-reveal-stagger">
            {STEPS.map((s) => (
              <div key={s.title} className="fv-step">
                <h4>{s.title}</h4>
                <p>{s.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* TESTIMONIAL + LOGOS */}
      <section id="about" className="fv-section" style={{ paddingTop: 0 }}>
        <div className="fv-container">
          <div className="fv-quote-grid fv-reveal">
            <div>
              <p className="fv-quote">
                “Finvera rebuilt our brand and pipeline in <em>one quarter</em>.
                It’s the rare studio where the strategy, design, and code all
                ship together.”
              </p>
              <div className="fv-quote__author">
                <div className="fv-quote__avatar">M</div>
                <div>
                  <div className="fv-quote__name">Maya Hernandez</div>
                  <div className="fv-quote__role">Head of Brand · Northbridge Capital</div>
                </div>
              </div>
            </div>
            <div className="fv-logos">
              {LOGOS.map((l) => (
                <div key={l} className="fv-logos__cell">{l}</div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA BANNER */}
      <section id="contact" className="fv-section" style={{ paddingTop: 0 }}>
        <div className="fv-container fv-reveal">
          <div className="fv-cta-banner">
            <h3>
              Let’s build something<br />
              <em>worth&nbsp;auditing.</em>
            </h3>
            <div className="fv-cta-banner__row">
              <a className="fv-btn fv-btn--invert" href="mailto:hello@finvera.studio" data-magnet>
                hello@finvera.studio <span className="fv-btn__arrow">→</span>
              </a>
              <a className="fv-btn" style={{ background: 'transparent', borderColor: 'rgba(255,255,255,0.4)' }} href="#" data-magnet>
                Book an intro call
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="fv-footer">
        <div className="fv-container">
          <div className="fv-footer__top">
            <div className="fv-footer__brand">
              <a className="fv-logo" href="#top" style={{ color: '#fff' }}>
                <span className="fv-logo__mark" aria-hidden="true" />
                <span>Finvera</span>
              </a>
              <p>Your trustable accounting partner. Independent studio for finance brands worldwide.</p>
            </div>
            <div className="fv-footer__col">
              <h5>Studio</h5>
              <ul>
                <li><a href="#services">Services</a></li>
                <li><a href="#work">Work</a></li>
                <li><a href="#process">Process</a></li>
                <li><a href="#about">About</a></li>
              </ul>
            </div>
            <div className="fv-footer__col">
              <h5>Connect</h5>
              <ul>
                <li><a href="#">LinkedIn</a></li>
                <li><a href="#">Dribbble</a></li>
                <li><a href="#">Behance</a></li>
                <li><a href="#">Instagram</a></li>
              </ul>
            </div>
            <div className="fv-footer__col">
              <h5>Contact</h5>
              <ul>
                <li><a href="mailto:hello@finvera.studio">hello@finvera.studio</a></li>
                <li><a href="#">+1 (415) 555-0117</a></li>
                <li><a href="#">San Francisco · Remote</a></li>
              </ul>
            </div>
          </div>
          <div className="fv-footer__big">Finvera</div>
          <div className="fv-footer__bottom">
            <span>© {new Date().getFullYear()} Finvera Studio. All rights reserved.</span>
            <span>Crafted with care · Made for finance</span>
          </div>
        </div>
      </footer>
    </main>
  );
}

function Loader() {
  return (
    <div className="fv-loader" aria-hidden="true">
      <div className="fv-loader__inner">
        <span className="fv-loader__bolt" />
        <span>Finvera</span>
        <span className="fv-loader__count">.studio</span>
      </div>
    </div>
  );
}

function Marquee() {
  const items = ['Brand', 'Product', 'Web', 'Motion', 'Editorial', 'Strategy'];
  const renderBlock = (groupKey) => (
    <div className="fv-marquee__item" key={groupKey}>
      {items.map((it, i) => (
        <span
          key={`${groupKey}-${i}`}
          style={{ display: 'inline-flex', alignItems: 'center', gap: 64 }}
        >
          {it} <i className="fv-marquee__star" />
        </span>
      ))}
    </div>
  );
  return (
    <div className="fv-marquee" aria-hidden="true">
      <div className="fv-marquee__track">
        {[0, 1, 2, 3].map((g) => renderBlock(g))}
      </div>
    </div>
  );
}
