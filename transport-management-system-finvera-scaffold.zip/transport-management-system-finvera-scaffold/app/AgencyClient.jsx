'use client';

import { useEffect, useRef, forwardRef } from 'react';

const NavBar = forwardRef(function NavBar(_, ref) {
  return (
    <nav ref={ref} className="fv-nav" aria-label="Primary">
      <div className="fv-container fv-nav__inner">
        <a className="fv-logo" href="#top" aria-label="Finvera home">
          <span className="fv-logo__mark" aria-hidden="true" />
          <span>Finvera</span>
        </a>
        <ul className="fv-nav__links">
          <li><a href="#services">Services</a></li>
          <li><a href="#work">Work</a></li>
          <li><a href="#process">Process</a></li>
          <li><a href="#about">About</a></li>
        </ul>
        <a className="fv-cta" href="#contact">
          <span className="fv-cta__dot" /> Start a project
        </a>
      </div>
    </nav>
  );
});

export default function AgencyClient() {
  const cursorRef = useRef(null);
  const navRef = useRef(null);

  useEffect(() => {
    if (typeof window === 'undefined') return;

    const cursor = cursorRef.current;
    const nav = navRef.current;

    let mx = window.innerWidth / 2;
    let my = window.innerHeight / 2;
    let cx = mx;
    let cy = my;
    let raf;

    const onMove = (e) => {
      mx = e.clientX;
      my = e.clientY;
    };

    const tick = () => {
      cx += (mx - cx) * 0.18;
      cy += (my - cy) * 0.18;
      if (cursor) cursor.style.transform = `translate(${cx}px, ${cy}px) translate(-50%, -50%)`;
      raf = requestAnimationFrame(tick);
    };

    const hoverables = document.querySelectorAll(
      '.fv-cta, .fv-btn, .fv-service, .fv-work__card, .fv-nav__links a, .fv-step, .fv-logos__cell, .fv-logo'
    );
    const onEnter = () => cursor && cursor.classList.add('is-hover');
    const onLeave = () => cursor && cursor.classList.remove('is-hover');
    hoverables.forEach((el) => {
      el.addEventListener('mouseenter', onEnter);
      el.addEventListener('mouseleave', onLeave);
    });

    const services = document.querySelectorAll('.fv-service');
    const onServiceMove = (e) => {
      const rect = e.currentTarget.getBoundingClientRect();
      e.currentTarget.style.setProperty('--mx', `${e.clientX - rect.left}px`);
      e.currentTarget.style.setProperty('--my', `${e.clientY - rect.top}px`);
    };
    services.forEach((s) => s.addEventListener('mousemove', onServiceMove));

    const onScroll = () => {
      if (!nav) return;
      if (window.scrollY > 40) nav.classList.add('is-scrolled');
      else nav.classList.remove('is-scrolled');
    };

    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-in');
            io.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15, rootMargin: '0px 0px -60px 0px' }
    );
    document.querySelectorAll('.fv-reveal, .fv-reveal-stagger').forEach((el) => io.observe(el));

    const counters = document.querySelectorAll('[data-count]');
    const counterIO = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          const el = entry.target;
          const target = parseFloat(el.getAttribute('data-count'));
          const decimals = (el.getAttribute('data-count').split('.')[1] || '').length;
          const suffix = el.getAttribute('data-suffix') || '';
          const duration = 1600;
          const start = performance.now();
          const step = (now) => {
            const p = Math.min(1, (now - start) / duration);
            const eased = 1 - Math.pow(1 - p, 3);
            const value = (target * eased).toFixed(decimals);
            el.textContent = value + suffix;
            if (p < 1) requestAnimationFrame(step);
          };
          requestAnimationFrame(step);
          counterIO.unobserve(el);
        });
      },
      { threshold: 0.4 }
    );
    counters.forEach((c) => counterIO.observe(c));

    const magnets = document.querySelectorAll('[data-magnet]');
    const onMagnetMove = (e) => {
      const r = e.currentTarget.getBoundingClientRect();
      const x = e.clientX - r.left - r.width / 2;
      const y = e.clientY - r.top - r.height / 2;
      e.currentTarget.style.transform = `translate(${x * 0.25}px, ${y * 0.35}px)`;
    };
    const onMagnetLeave = (e) => {
      e.currentTarget.style.transform = 'translate(0,0)';
    };
    magnets.forEach((m) => {
      m.addEventListener('mousemove', onMagnetMove);
      m.addEventListener('mouseleave', onMagnetLeave);
    });

    window.addEventListener('mousemove', onMove);
    window.addEventListener('scroll', onScroll, { passive: true });
    raf = requestAnimationFrame(tick);
    onScroll();

    return () => {
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('scroll', onScroll);
      cancelAnimationFrame(raf);
      hoverables.forEach((el) => {
        el.removeEventListener('mouseenter', onEnter);
        el.removeEventListener('mouseleave', onLeave);
      });
      services.forEach((s) => s.removeEventListener('mousemove', onServiceMove));
      magnets.forEach((m) => {
        m.removeEventListener('mousemove', onMagnetMove);
        m.removeEventListener('mouseleave', onMagnetLeave);
      });
      io.disconnect();
      counterIO.disconnect();
    };
  }, []);

  return (
    <>
      <span ref={cursorRef} className="fv-cursor" aria-hidden="true" />
      <NavBar ref={navRef} />
    </>
  );
}
