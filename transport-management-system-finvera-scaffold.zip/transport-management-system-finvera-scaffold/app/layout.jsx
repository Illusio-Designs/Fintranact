import './globals.css';

export const metadata = {
  title: 'Finvera — Your Trustable Accounting Partner',
  description:
    'Finvera is a creative accounting & finance agency crafting trustable digital experiences, brand systems, and growth strategies for ambitious companies.',
  icons: {
    icon: '/finvera-mark.png',
  },
};

export const viewport = {
  themeColor: '#f5f4ef',
  width: 'device-width',
  initialScale: 1,
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <div className="finvera-root">{children}</div>
      </body>
    </html>
  );
}
