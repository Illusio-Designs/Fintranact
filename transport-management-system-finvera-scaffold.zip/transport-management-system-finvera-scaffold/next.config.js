/** @type {import('next').NextConfig} */
const isPagesBuild = process.env.GITHUB_PAGES === 'true';
const repo = 'Finvera';

const nextConfig = {
  reactStrictMode: true,
  ...(isPagesBuild && {
    output: 'export',
    basePath: `/${repo}`,
    assetPrefix: `/${repo}/`,
    images: { unoptimized: true },
    trailingSlash: true,
  }),
};

module.exports = nextConfig;
