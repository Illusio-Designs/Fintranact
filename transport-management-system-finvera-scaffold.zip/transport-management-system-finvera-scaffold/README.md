# Finvera

Your Trustable Accounting Partner. Agency landing site built with Next.js 15.

## Local development

```bash
npm install
npm run dev
# → http://localhost:3000
```

## Production build

```bash
npm run build
npm start
```

## Deploying to GitHub Pages

A workflow at `.github/workflows/pages.yml` builds a static export and
publishes it to GitHub Pages on every push to `main` or `agency`.

To enable:

1. Go to **Settings → Pages**
2. Set **Build and deployment → Source** to **GitHub Actions**

Live URL once deployed: `https://<owner>.github.io/Finvera/`

## Deploying to Vercel

Just import the repo at https://vercel.com/new — no extra config required.
The `GITHUB_PAGES` env var is unset on Vercel, so the basePath is skipped
and the site serves at the root.
